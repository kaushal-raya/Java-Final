package org.example.DataBaseConnection;

public class Pass {
    public  String password;
    public Pass() {
        this.password = "kaushal@999";
    }
    public String getPassword() {
        return password;
    }
}
